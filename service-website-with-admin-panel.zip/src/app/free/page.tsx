import Link from "next/link";
import { getSettings } from "@/lib/settings";

function getYoutubeId(url: string): string | null {
  const match = url.match(
    /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{6,})/,
  );
  return match ? match[1] : null;
}

export const dynamic = "force-dynamic";

export default async function FreeVideoPage() {
  const s = await getSettings();
  const videoId = s.freeVideoLink ? getYoutubeId(s.freeVideoLink) : null;

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-slate-950 px-5 py-16 text-white">
      <div className="w-full max-w-2xl rounded-3xl border border-white/10 bg-white/[0.04] p-8 text-center backdrop-blur">
        <span className="inline-block rounded-full bg-red-600 px-4 py-1 text-xs font-bold uppercase tracking-wide">
          🎁 Free Gift
        </span>
        <h1 className="mt-4 text-2xl font-extrabold sm:text-3xl">Enjoy This Free Video!</h1>
        <p className="mt-2 text-sm text-slate-400">
          A special free resource from {s.siteName}. Message us on WhatsApp if you have any questions.
        </p>

        <div className="mt-8 overflow-hidden rounded-2xl border border-white/10">
          {videoId ? (
            <div className="aspect-video">
              <iframe
                className="h-full w-full"
                src={`https://www.youtube.com/embed/${videoId}`}
                title="Free Video"
                allow="accelerate; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          ) : s.freeVideoLink ? (
            <a
              href={s.freeVideoLink}
              target="_blank"
              rel="noreferrer"
              className="flex aspect-video items-center justify-center bg-gradient-to-br from-fuchsia-700 to-violet-800 text-lg font-bold"
            >
              ▶ Watch Free Video
            </a>
          ) : (
            <div className="flex aspect-video items-center justify-center bg-slate-900 text-sm text-slate-500">
              No free video has been added yet. Please check back soon.
            </div>
          )}
        </div>

        <Link
          href="/"
          className="mt-8 inline-block rounded-full bg-gradient-to-r from-fuchsia-500 to-violet-600 px-6 py-3 text-sm font-bold text-white"
        >
          ← Back to Home
        </Link>
      </div>
    </main>
  );
}
